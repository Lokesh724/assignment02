$(document).ready(function () {
    // Optionally validate fields before submission or add interactive behavior
    $("#registrationForm").on("submit", function (event) {
        // Add custom validation logic here if needed
        alert("Form submitted successfully!");
    });
});
